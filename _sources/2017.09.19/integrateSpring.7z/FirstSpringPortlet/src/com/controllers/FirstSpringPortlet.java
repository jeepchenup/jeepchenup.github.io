package com.controllers;

import javax.portlet.RenderRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("VIEW")
public class FirstSpringPortlet {
	
	@RequestMapping
	public String showIndex(RenderRequest request) {
		request.setAttribute("name", "Steven");
		return "index";
	}
}
